from authlib.jose import JWTClaims
