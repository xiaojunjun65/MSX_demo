from authlib.jose import JWEAlgorithm, JWEEncAlgorithm, JWEZipAlgorithm
