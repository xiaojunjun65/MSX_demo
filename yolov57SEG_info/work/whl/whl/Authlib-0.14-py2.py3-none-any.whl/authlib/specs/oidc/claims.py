from authlib.oidc.core.claims import *
