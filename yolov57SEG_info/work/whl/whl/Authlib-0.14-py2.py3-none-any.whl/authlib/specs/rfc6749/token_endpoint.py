from authlib.oauth2.rfc6749.token_endpoint import *
