from authlib.jose import JWS_ALGORITHMS

__all__ = ['JWS_ALGORITHMS']
