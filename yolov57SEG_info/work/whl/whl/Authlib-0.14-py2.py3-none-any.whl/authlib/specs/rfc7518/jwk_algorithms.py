from authlib.jose import JWK_ALGORITHMS

__all__ = ['JWK_ALGORITHMS']
