from authlib.integrations._client import RemoteApp as OAuthClient
from authlib.integrations._client.oauth_registry import OAUTH_CLIENT_PARAMS

__all__ = ['OAUTH_CLIENT_PARAMS', 'OAuthClient']
